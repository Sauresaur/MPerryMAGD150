let storm;
let x;
let y;
  
function cloud (x,y,storm) {
    fill(storm,storm,storm)
    circle(x,y,100);
    circle(x-20,y+20,100);
    circle(x+20,y+20,100);
 circle(x-70,y+20,100);
 circle(x+70,y+20,100);}

function setup() {
  noStroke();
  
  createCanvas(400, 400);
  colorMode(RGB)
  
  print(printValues());
 
  function printValues(){

     return "It's raining!";
    }
   
  
  
  
}

function draw() {
 
  background(220);
  translate(50,50); //translating it so we can see the entire cloud
    
  let x = random(197,200);
  let y = random(0,3);
  let storm = fill(250,250,250);
  cloud(x,y);
  
for(let i = 0; i < 5; i++) {
  angleMode(DEGREES);
  rotate(1);
  scale(1.05);
  let x = random(100,103);
  let y = random(12,15);
  let storm = color(random(190,200), random(190,200), random(190,200)); //setting the variable i so that it runs 5 times. The scale function makes it bigger than before. Defining x and y at separate coordinates so that the clouds are both visable. Making the color randomized so that it changes slightly and quickly.
  
  cloud(x,y,storm); //then we call the function again with these changes.
  
  for(let r = 0; r < 5; r++){
    fill(12,0,100);
    ellipse(random(0,200),random(100,400),4,8); //here is the rain
    
    push();
    translate(mouseX, mouseY);
    fill(5,0,100);
    circle(random(0,5),random(0,5),1);
    pop();
    
    
    
    
  }
  
  }
  

  
  
  
}
