let mouse=[];
let dots=[]; //array
function setup() {
  createCanvas(400, 400);
  colorMode(RGB);
  frameRate(10);
  for (let i = 0; i < width; i++) {dots [i] = 400-i;} //put the "for" inside the setup so it recognizes it. Start with i being equal to 0, then as long as it is less than the edge of the canvas, add 1. Then, set the array value to be 400 - the value of i, which is constantly adding 1.
  
  
  dots[10] = mouseX;
    
}

function draw() {
  
 background(220);
  
  for (let i=0; i<width; i++){
    
    
 
   
     background(220);
    fill(200,100,0);
    circle (dots[i],100,100);
    dots[i]++;
    
    dots[10] = mouseX;  
    circle(dots[10],30,30);
    
    
     
    
     
  }
    print(dots);
}




