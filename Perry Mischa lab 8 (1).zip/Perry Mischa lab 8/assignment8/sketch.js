let fox;
let relaxing;
let bug;
let x=30;
  let y=40;
  let w=100;
  let h=100;
let flyX=200;
let flyY=20;
let flyW=100;
let flyH=100;
function preload(){
 fox=loadImage('/assets/polarfox.jpg'); //pixabay https://pixabay.com/photos/fox-white-fox-animal-canine-7593977/
  
 relaxing=loadImage('/assets/winterfox.jpg'); //pixabay https://pixabay.com/photos/polar-fox-fox-wild-animal-predator-4790151/
  
  bug=loadImage('/assets/butterfly.png'); //pixabay https://pixabay.com/vectors/butterfly-transparent-insect-animal-161156/

}
function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(220);
  textSize(25);
  textAlign(CENTER,CENTER);
  stroke(10);
  fill(200,0,50);
 textFont('Gotham');
  text("Foxes and a butterfly",225,200);
    image(relaxing,x,y,w,h,);
  image(fox,170,220,150,150);
  image(bug,flyX,flyY,flyW,flyH);
  
 if(mouseX>=30 && mouseX<=120 && mouseY>=40 && mouseY<=120) {x = 200}
  if(mouseX<=250 && mouseX>=200 && mouseY<=100 && mouseY>=50){flyY = 80}
}
  
  
  
  
  